if ("serviceWorker" in navigator) {
	navigator.serviceWorker
		.register("/sw.js", { scope: "/" })
		.then((reg) => {
			console.log("Service Worker Registered", reg);
		})
		.catch((err) => {
			console.log("Service Worker Registration Failed : ", err);
		});
} else {
	console.log("Service Worker Not Supported");
}
